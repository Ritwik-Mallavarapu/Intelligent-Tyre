"""Shared definitions for synthetic input, feature extraction and exported inference."""
import hashlib
import json
from pathlib import Path
import numpy as np
FS=99.84;N=256
LABELS=['Warming up','Normal','Unbalanced','Uncertain','Too slow','Too fast','Sensor clipped','Speed unstable','Sampling irregular','IMU unavailable','Check mounting']
DETAILS=[
 'Collecting the first 256-sample window; allow about 2.56 seconds.',
 'Model score is at or below 35%. Physical accuracy is not yet established.',
 'Model score is at or above 65%. This is a learned signal classification, not an imbalance mass measurement.',
 'Score is between 35% and 65%. The model abstains instead of forcing a label.',
 'Hold the wheel between 78 and 162 RPM. Start around 120 RPM.',
 'Reduce speed below 162 RPM; this speed is outside the training range.',
 'Axial acceleration or Z gyroscope reached its limit. Reduce speed and inspect the mount.',
 'Hold speed steady. Variation exceeded 5% during the measurement window.',
 'IMU sample timing is irregular. Restart the board and inspect sensor/bus operation.',
 'Motion sensor or 16g range setup failed. Reboot the board; inspect Serial Monitor at 115200.',
 'Z is not aligned with the axle. Mount the board face parallel to the wheel plane.'
]

def model_fingerprint(model):
    values=np.concatenate([model['mean'],model['scale'],np.asarray(model['w1']).ravel(),model['b1'],model['w2'],[model['b2']]])
    return int.from_bytes(hashlib.sha256(values.astype('<f4').tobytes()).digest()[:4],'little')

class Model:
    def __init__(self,path):
        self.data=json.loads(Path(path).read_text());m=self.data
        for key,shape in [('mean',(6,)),('scale',(6,)),('w1',(6,8)),('b1',(8,)),('w2',(8,))]:
            value=np.asarray(m[key],dtype=float)
            if value.shape!=shape or not np.isfinite(value).all():raise ValueError(f'Model parameter {key} is invalid; restore model.json from this package.')
            setattr(self,key,value)
        if np.any(self.scale<=0) or not np.isfinite(m['b2']):raise ValueError('Model scaling/bias is invalid.')
        self.b2=float(m['b2']);self.fingerprint=model_fingerprint(m)
        if m.get('fingerprint')!=self.fingerprint:raise ValueError('Model fingerprint invalid. Restore the matching model.json and Arduino model.h.')
    def predict(self,x):
        x=np.asarray(x,dtype=float)
        if x.shape!=(6,) or not np.isfinite(x).all():raise ValueError('Invalid motion features')
        h=np.maximum(0,((x-self.mean)/self.scale)@self.w1+self.b1)
        return float(1/(1+np.exp(-np.clip(h@self.w2+self.b2,-50,50))))

def features(z,f,t=None):
    z=np.asarray(z,dtype=float);t=np.arange(len(z))/FS if t is None else np.asarray(t)
    q=z-z.mean();c=np.cos(2*np.pi*f*t);s=np.sin(2*np.pi*f*t);c-=c.mean();s-=s.mean()
    cc=c@c;ss=s@s;cs=c@s;det=max(cc*ss-cs*cs,1e-12)
    a=((q@c)*ss-(q@s)*cs)/det;b=((q@s)*cc-(q@c)*cs)/det
    amp=np.hypot(a,b);rms=np.sqrt(np.mean(q*q));rr=np.sqrt(np.mean((q-a*c-b*s)**2));scale=max(f*f,.25)
    return np.array([rms/scale,amp/scale,rr/scale,amp/(rms+1e-6),np.max(np.abs(q))/(rms+1e-6),f])

def simulate(rng,mass,rpm):
    # Same signal family as the training generator; transfer is an assumed rig response.
    t=np.arange(N)/FS;f=rpm/60;phase=rng.uniform(0,2*np.pi);amp=mass*.00018*f*f
    z=(.002*np.sin(2*np.pi*f*t+rng.uniform(0,2*np.pi))+amp*np.sin(2*np.pi*f*t+phase)
       +rng.uniform(.05,.4)*amp*np.sin(4*np.pi*f*t+phase)+rng.normal(0,.002,N)
       +rng.uniform(.0005,.004)*np.sin(2*np.pi*rng.uniform(12,35)*t+phase))
    return t,z

def classify(score):return 2 if score>=.65 else 1 if score<=.35 else 3
