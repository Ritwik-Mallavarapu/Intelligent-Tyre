"""Offline setup diagnostic; does not require an Arduino or BLE connection."""
from pathlib import Path
import importlib,sys
ROOT=Path(__file__).resolve().parent
errors=[]
for module in ('numpy','bleak'):
    try:importlib.import_module(module)
    except Exception as exc:errors.append(f'{module}: {exc}. Run SETUP_WINDOWS.bat again.')
for file in ('model.json','training_report.json','ml.py','protocol.py','static/index.html','static/style.css','static/app.js'):
    if not (ROOT/file).is_file():errors.append(f'Missing {file}. Extract the entire Friend_Demo folder.')
if not errors:
    try:
        from ml import Model
        model=Model(ROOT/'model.json');print(f'Model OK: {model.fingerprint:08X}. Synthetic inference ready.')
        (ROOT/'logs').mkdir(exist_ok=True)
        test=ROOT/'logs'/'write_check.tmp';test.write_text('ok');test.unlink()
    except Exception as exc:errors.append(f'{exc}. Put the folder in Documents and restore its files from the ZIP.')
if errors:
    print('INSTALLATION ISSUES:')
    for error in errors:print(' -',error)
    sys.exit(1)
print('Installation checks passed. Bluetooth hardware is checked when selecting Live Arduino.')
