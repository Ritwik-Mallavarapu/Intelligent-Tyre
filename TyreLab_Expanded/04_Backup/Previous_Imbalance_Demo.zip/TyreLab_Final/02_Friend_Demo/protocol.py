"""Final firmware protocol; two BLE notifications, each within20-byte default payload."""
import struct
SERVICE='7b110001-89ab-4cde-9012-34567890abcd'
MOTION='7b110002-89ab-4cde-9012-34567890abcd'
ENVIRONMENT='7b110003-89ab-4cde-9012-34567890abcd'
PA_PER_PSI=6894.757293168

def decode_motion(data):
    if len(data)!=20:raise ValueError(f'Motion packet is {len(data)} bytes; expected 20. Upload final TyreLabRev2 firmware.')
    ms,ax,ay,az,gz,p,rpm,state,version,seq=struct.unpack('<IhhhhHHBBH',data)
    if version!=3:raise ValueError(f'Firmware protocol {version} is outdated/incompatible. Upload TyreLabRev2.ino from 01_Arduino_Upload.')
    if state>10 or p>10000:raise ValueError('Motion packet contains an invalid state or score.')
    return dict(device_ms=ms,ax=ax/1000,ay=ay/1000,az=az/1000,gz=gz/10,score=p/10000,rpm=rpm/10,state=state,seq=seq)

def decode_environment(data):
    if len(data)!=20:raise ValueError('Environment packet has wrong length. Upload final firmware.')
    pa,temp,rh,gx,gy,window,faults,model_id=struct.unpack('<IhHhhHHI',data)
    if pa and not 26000<=pa<=126000:raise ValueError('Pressure packet is outside the LPS22HB physical range.')
    if temp!=-32768 and not -4000<=temp<=12500:raise ValueError('Temperature packet is out of range.')
    if rh!=65535 and rh>10000:raise ValueError('Humidity packet is out of range.')
    return dict(pressure_psi=pa/PA_PER_PSI if pa else None,temperature_c=temp/100 if temp!=-32768 else None,
                humidity_pct=rh/100 if rh!=65535 else None,gx=gx/10,gy=gy/10,window=window,faults=faults,model_id=model_id)
