@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
 echo Run SETUP_WINDOWS.bat first.
 pause
 exit /b 1
)
.venv\Scripts\python.exe CHECK_INSTALLATION.py
if errorlevel 1 (
 pause
 exit /b 1
)
.venv\Scripts\python.exe app.py
if errorlevel 1 echo Demo stopped with an error. Read the message above.
pause
