# Your demo setup on Windows

You only need this complete **02_Friend_Demo** folder. The Arduino must already have the final firmware uploaded by Ritwik. You do not install Arduino IDE or edit Arduino code.

## Setup once, before the demo

1. Install **Python 3.11 or 3.12**, including the Python launcher, from https://www.python.org/downloads/windows/ . SETUP_WINDOWS detects those versions explicitly.
2. Extract this complete folder into a writable location such as Documents/TyreLab. Do not run from inside the ZIP. Do not copy a virtual environment from another laptop.
3. Double-click **SETUP_WINDOWS.bat**. It needs internet once to install numpy and bleak into a local .venv. It checks model files and write permissions.
4. Double-click **START_DEMO.bat**. Keep its console window open. The browser opens http://127.0.0.1:8000 . Start with synthetic playback to verify everything.
5. For Live Arduino, turn on Bluetooth and power the board. Select **Live Arduino** on the website. No Windows pairing step is needed first. Close nRF Connect or other apps connected to this board.

After setup, operation needs no internet. A Windows 10/11 BLE adapter is required only for Live Arduino. Hardware compatibility must be checked on your laptop before the event.

## Website modes

**Live Arduino**: real sensors and the prediction computed on the board. Connection, data stream and model match appear in the left sidebar. The mass slider is hidden. Ambient pressure is PSI absolute outside the tyre; temperature is near the board. A missing sensor is reported rather than replaced with made-up readings.

**Synthetic playback**: no board is required. Generated motion alternates between 6 g and 55 g approximately every16 seconds. The laptop evaluates the same model and preprocessing as the Arduino. Pressure, temperature, humidity and motion are labelled simulated. No physical performance claim follows from this mode.

**Manual simulation**: the0–100 g slider adjusts the mass used to generate motion. Adjust RPM within 78–162 if needed. Release the slider and allow a complete window, about 3 seconds, for the next prediction. A slider change restarts the simulation window; it never directly sets the result. Above60 g is outside the abnormal training mass range and is labelled exploratory. Normal training mass was 0–12 g; intermediate 12–50 g values also explore an untrained transition.

Switching modes stops the previous source and clears its plots/readings. Selecting simulation disconnects the BLE session instead of mixing live and generated values. Selecting Live starts scan/reconnect. No silent fallback to synthetic data occurs.

## Common issues and fixes

- **No board found**: power board, enable Bluetooth, bring laptop closer and close other BLE apps. Scan retries automatically.
- **Old firmware**: Ritwik must upload the final TyreLabRev2 sketch. Friend-side mode switching cannot upgrade old firmware.
- **Model mismatch**: Arduino model.h and laptop model.json are from different versions. Use the matching files from this package.
- **Connected but no motion**: restart board and inspect sensor status. The website distinguishes connected from receiving fresh readings.
- **Data stale**: scores stop displaying after 2 seconds without motion. Environment values disappear after 4 seconds without that stream.
- **IMU unavailable / sensor failed**: reboot board; if persistent, ask Ritwik to inspect the board/Serial output. Environment failure does not fabricate values.
- **Too slow/fast**: operate between 78–162 RPM. Stationary Too slow is expected.
- **Check mounting**: board Z must point along axle.
- **Sampling irregular/speed unstable**: hold speed steady and restart board if irregular timing persists.
- **Missing Python/modules**: run SETUP_WINDOWS again. Installation errors remain visible in the console.
- **Port busy**: close the other demo console, or run `.venv\Scripts\python.exe app.py --port 8001` in a terminal inside this folder. Open the printed URL.
- **Multiple boards**: turn off other units, or run `app.py --address ACTUAL_BLE_ADDRESS` using the actual board address.

Don't close the console while presenting. Ctrl+C stops the app. The browser alone cannot run the backend.

## Logging and physical test labels

Data automatically saves to logs/tyrelab_TIMESTAMP.csv. The website's Download session CSV button exports the current session. Diagnostic issues also go to logs/diagnostics.log. Each row includes mode; never mix simulated and live data in a physical accuracy calculation.

Physical validation controls appear only in Live Arduino. Set a unique run ID and known normal/unbalanced condition before each independent run. Labels only annotate the CSV and never change the prediction. Set Unlabelled between runs or while changing weights/speed. Wait at least 6 seconds after labelling/starting, and record 20 seconds per run.

Aim for 10 normal and 10 weighted independent starts, with matched speeds and randomized order. Evaluate using `.venv\Scripts\python.exe evaluate_real.py logs\tyrelab_TIMESTAMP.csv`. This reports one majority decision per run, treats uncertain/invalid/model-unverified decisions as failures, excludes transitions, and gives a confidence interval. Do not call many packets from one spin independent tests.

## What to say accurately

Synthetic binary test accuracy:94.03%. Conservative deployed decision success with abstentions counted wrong:83.89% on the synthetic test. Real-wheel accuracy has not been established until the physical tests are done. This is a prototype, not a validated TPMS or calibrated wheel balancer. It does not estimate physical imbalance mass.

A rim-mounted barometer reads ambient pressure, not tyre inflation pressure. The board's pressure range is only about 3.77–18.28 PSI absolute. No extra pressure sensor is needed to demonstrate its ambient reading, but tyre pressure requires an appropriate external transducer.
