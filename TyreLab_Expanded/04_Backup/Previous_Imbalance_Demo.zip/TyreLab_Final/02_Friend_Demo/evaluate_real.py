"""One majority decision per independently labelled physical run; not per BLE packet."""
import argparse,csv,json
from collections import defaultdict,Counter
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('csv',nargs='+');args=p.parse_args()
runs=defaultdict(list)
for filename in args.csv:
    with open(filename,newline='') as fp:
        for row in csv.DictReader(fp):
            if row['mode']=='live' and row['truth'] in ('normal','unbalanced') and row['run_id'] not in ('','unlabelled'):
                runs[(filename,row['run_id'])].append(row)
results=[];skipped=[]
for (filename,run),rows in runs.items():
    truths={r['truth'] for r in rows}
    start=min(float(r['time']) for r in rows);duration=max(float(r['time']) for r in rows)-start
    if len(truths)!=1 or duration<15:
        skipped.append({'run':run,'reason':'mixed labels or duration under 15 seconds'});continue
    # Discard transition windows; abstentions/invalid states count against success.
    counts=Counter('normal' if r['score'] and int(r['state'])==1 else 'unbalanced' if r['score'] and int(r['state'])==2 else 'invalid_or_uncertain' for r in rows if float(r['time'])>=start+6)
    leaders=counts.most_common();decision=leaders[0][0] if leaders and (len(leaders)==1 or leaders[0][1]>leaders[1][1]) else 'invalid_or_uncertain'
    truth=next(iter(truths));results.append({'file':filename,'run':run,'truth':truth,'prediction':decision,'correct':truth==decision})
n=len(results);correct=sum(r['correct'] for r in results)
recalls={label:sum(r['correct'] for r in results if r['truth']==label)/sum(r['truth']==label for r in results) if any(r['truth']==label for r in results) else None for label in ('normal','unbalanced')}
report={'runs':results,'skipped':skipped,'evaluated_runs':n,'accuracy':correct/n if n else None,'class_recall':recalls,'balanced_accuracy':sum(recalls.values())/2 if all(v is not None for v in recalls.values()) else None,'note':'Use independently restarted runs and matched speeds, not many labels from one unchanged spin. Small-sample result is provisional.'}
if n:
    ph=correct/n;z=1.96;den=1+z*z/n;centre=(ph+z*z/(2*n))/den;half=z*((ph*(1-ph)/n+z*z/(4*n*n))**.5)/den
    report['wilson_95_interval']=[centre-half,centre+half]
out=Path('physical_test_report.json');out.write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
