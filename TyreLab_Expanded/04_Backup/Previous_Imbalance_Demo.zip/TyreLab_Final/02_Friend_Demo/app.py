"""Windows-friendly local BLE dashboard. Modes change via website, never firmware."""
import argparse,asyncio,csv,json,logging,math,os,sys,threading,time,webbrowser
from collections import deque
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
import numpy as np
from ml import Model,features,simulate,classify,FS,N,LABELS,DETAILS
from protocol import SERVICE,MOTION,ENVIRONMENT,decode_motion,decode_environment,PA_PER_PSI
ROOT=Path(__file__).resolve().parent
FAULTS={
 1:('IMU_INIT','Motion sensor did not initialize.','Restart board; check Arduino_BMI270_BMM150 and Serial Monitor.'),
 2:('IMU_RANGE','16g accelerometer configuration failed.','Restart board. Use the official BMI270 library; check sketch Serial output.'),
 4:('PRESSURE_INIT','Onboard LPS22HB pressure sensor did not initialize.','Restart board; confirm it is Nano 33 BLE SENSE Rev2, not the BLE-only board.'),
 8:('TEMPERATURE_INIT','Onboard HS3003 temperature/humidity sensor did not respond.','Restart board; confirm Sense Rev2 model.'),
 16:('PRESSURE_READ','Pressure read failed or is outside the sensor range.','Wait for next sample; restart board if persistent.'),
 32:('TEMPERATURE_READ','Temperature/humidity data was invalid or unavailable.','Wait for next sample; restart board if persistent.'),
 64:('RADIAL_CLIP','An in-plane accelerometer axis is clipping.','Reduce wheel speed. Axial model uses Z, but these X/Y readings are saturated.')}

class Engine:
    def __init__(self,model,report,log_dir,diameter=.6729,address=None,default_mode='synthetic'):
        self.model=model;self.report=report;self.diameter=diameter;self.address=address
        self.lock=threading.RLock();self.stop=threading.Event();self.revision=0
        self.settings={'mode':default_mode,'grams':55.,'rpm':120.}
        self.history=deque(maxlen=500);self.events=deque(maxlen=30);self.arrivals=deque(maxlen=300)
        self.issues={};self.last_seq=None;self.started=time.time();self.window=0;self.last_env=None
        self.state={};self.reset(default_mode)
        log_dir.mkdir(parents=True,exist_ok=True)
        self.log_path=log_dir/time.strftime('tyrelab_%Y%m%d_%H%M%S.csv');self.fp=self.log_path.open('w',newline='')
        self.writer=csv.DictWriter(self.fp,fieldnames=['time','mode','run_id','truth','device_ms','ax','ay','az','gx','gy','gz','score','rpm','state','seq','window','pressure_psi','temperature_c','humidity_pct','simulated_mass_g'])
        self.writer.writeheader();self.last_flush=time.monotonic()
    def reset(self,mode):
        with self.lock:
            self.history.clear();self.arrivals.clear();self.issues.clear();self.last_seq=None;self.last_env=None;self.window=0
            self.state={'mode':mode,'connection':'Starting','stream':'Waiting','label':'Waiting','detail':'Starting selected source.',
             'score':None,'rpm':None,'speed_kmh':None,'pressure_psi':None,'temperature_c':None,'humidity_pct':None,
             'ax':None,'ay':None,'az':None,'gx':None,'gy':None,'gz':None,'last_seen':None,'received':0,'dropped':0,
             'model_verified':mode!='live','truth':'unlabelled','run_id':'unlabelled','simulated_mass_g':None,'windows':0}
    def issue(self,code,message,fix,severity='error'):
        with self.lock:
            item={'code':code,'message':message,'fix':fix,'severity':severity,'time':time.time()}
            if self.issues.get(code,{}).get('message')!=message:
                self.events.append(item);logging.warning('%s: %s %s',code,message,fix)
            self.issues[code]=item
    def clear(self,*codes):
        with self.lock:
            for code in codes:self.issues.pop(code,None)
    def configure(self,body):
        with self.lock:
            mode=body.get('mode',self.settings['mode'])
            if mode not in ('live','synthetic','manual'):raise ValueError('Choose live, synthetic or manual mode.')
            grams=float(body.get('grams',self.settings['grams']));rpm=float(body.get('rpm',self.settings['rpm']))
            if not math.isfinite(grams) or not 0<=grams<=100:raise ValueError('Imbalance must be 0–100 grams.')
            if not math.isfinite(rpm) or not 78<=rpm<=162:raise ValueError('Simulation speed must be 78–162 RPM.')
            new={'mode':mode,'grams':grams,'rpm':rpm}
            if new!=self.settings:
                self.settings=new;self.revision+=1;self.reset(mode)
                self.events.append({'time':time.time(),'code':'MODE_CHANGE','message':f'Source changed to {mode}.','fix':'','severity':'info'})
            return dict(self.settings)
    def annotate(self,body):
        with self.lock:
            if self.settings['mode']!='live':raise ValueError('Physical labels are only available in Live Arduino mode.')
            truth=body.get('truth');run=str(body.get('run_id','')).strip()
            if truth not in ('normal','unbalanced','unlabelled'):raise ValueError('Invalid physical ground truth.')
            if truth!='unlabelled' and not run:raise ValueError('Enter a unique run ID, such as normal_01.')
            if len(run)>80:raise ValueError('Run ID must be 80 characters or fewer.')
            self.state.update(truth=truth,run_id=run or 'unlabelled')
    def publish(self,packet,revision):
        with self.lock:
            if revision!=self.revision:return
            now=time.time();self.arrivals.append(now)
            seq=packet['seq']
            if self.last_seq is not None:
                delta=(seq-self.last_seq)%65536
                if 0<delta<32768:self.state['dropped']+=max(delta-1,0)
                elif delta==0:return
                else:self.events.append({'time':now,'code':'DEVICE_RESTART','message':'Packet sequence restarted.','fix':'Wait for a fresh measurement window.','severity':'info'})
            self.last_seq=seq;status=packet['state'];valid=status in (1,2,3)
            verified=self.state['model_verified'];label=LABELS[status] if verified else 'Model mismatch / checking'
            self.state.update(label=label,detail=DETAILS[status] if verified else 'Verify matching firmware and laptop model before interpreting predictions.',
                score=packet['score'] if valid and verified else None,rpm=packet['rpm'],
                speed_kmh=packet['rpm']*self.diameter*math.pi*60/1000,
                ax=packet['ax'],ay=packet['ay'],az=packet['az'],gz=packet['gz'],last_seen=now,stream='Receiving data')
            self.state['received']+=1
            row={k:packet.get(k) for k in self.writer.fieldnames};row.update(time=now,mode=self.state['mode'],run_id=self.state['run_id'],truth=self.state['truth'],
                gx=self.state['gx'],gy=self.state['gy'],window=self.state['windows'],pressure_psi=self.state['pressure_psi'],temperature_c=self.state['temperature_c'],humidity_pct=self.state['humidity_pct'],simulated_mass_g=self.state['simulated_mass_g'])
            row['score']=self.state['score'];self.history.append(row)
            try:
                self.writer.writerow(row)
                if time.monotonic()-self.last_flush>1:self.fp.flush();self.last_flush=time.monotonic()
            except OSError as exc:self.issue('LOG_WRITE',f'CSV could not be written: {exc}','Move demo folder to a writable location and restart.')
    def consume_environment(self,data,revision):
        with self.lock:
            if revision!=self.revision:return
            try:
                env=decode_environment(data);match=env['model_id']==self.model.fingerprint
                self.state['model_verified']=match;self.last_env=time.time()
                if not match:self.issue('MODEL_MISMATCH','Arduino and laptop models do not match.','Upload model.h from this final package; give friend its matching model.json.')
                else:self.clear('MODEL_MISMATCH','ENV_PACKET')
                self.state.update({k:env[k] for k in ('pressure_psi','temperature_c','humidity_pct','gx','gy')});self.state['windows']=env['window']
                for bit,(code,msg,fix) in FAULTS.items():
                    if env['faults']&bit:self.issue(code,msg,fix,'warning' if bit in (4,8,16,32,64) else 'error')
                    else:self.clear(code)
            except ValueError as exc:self.issue('ENV_PACKET',str(exc),'Upload final firmware; restart BLE connection.')
    def snapshot(self):
        with self.lock:
            state=dict(self.state);now=time.time();age=None if state['last_seen'] is None else now-state['last_seen']
            while self.arrivals and self.arrivals[0]<now-5:self.arrivals.popleft()
            state['rate_hz']=len(self.arrivals)/min(5,max(.1,now-self.arrivals[0]+.04)) if self.arrivals else 0
            if state['mode']=='live' and age is not None and age>2:
                state.update(label='Data stale',detail='BLE connection may exist, but fresh motion readings are not arriving.',score=None,stream='No fresh data')
            env_age=None if self.last_env is None else now-self.last_env
            if state['mode']=='live' and (env_age is None or env_age>4):
                state.update(pressure_psi=None,temperature_c=None,humidity_pct=None,gx=None,gy=None)
            if state['mode']=='live' and not state['model_verified']:
                state.update(score=None,label='Checking model' if 'MODEL_MISMATCH' not in self.issues else 'Model mismatch')
            issues=list(self.issues.values())
            if state['mode']=='live' and state['connection']=='Connected' and (age is None and now-self.started>5 or age is not None and age>2):
                issues.append({'code':'NO_MOTION_DATA','message':'Connected, but motion data is not arriving.','fix':'Restart board; check IMU state, Bluetooth signal and firmware.','severity':'error'})
            if state['mode']=='live' and state['connection']=='Connected' and env_age is not None and env_age>4:
                issues.append({'code':'ENV_STALE','message':'Pressure/temperature stream is stale.','fix':'Restart board or BLE connection.','severity':'warning'})
            if state['mode']=='manual' and self.settings['grams']>60:
                issues.append({'code':'SIMULATION_RANGE','message':'Selected mass is above the 50–60 g abnormal mass range used in training.','fix':'Use this to explore the simulator, not to claim validated accuracy at this mass.','severity':'warning'})
            if state['mode']=='manual' and 12<self.settings['grams']<50:
                issues.append({'code':'SIMULATION_TRANSITION','message':'This mass is between the normal and abnormal training ranges.','fix':'Treat its prediction as an exploratory simulator response, not validated detection at this mass.','severity':'warning'})
            return {'state':state,'settings':dict(self.settings),'history':list(self.history),'issues':issues,'events':list(self.events),'report':self.report,'age_seconds':age,
                'environment_age_seconds':env_age,'model_id':self.model.fingerprint,'log_name':self.log_path.name}
    async def synthetic(self,revision,settings):
        rng=np.random.default_rng(20261005);seq=0;start=time.monotonic();previous=.5;previous_state=0;window=0
        with self.lock:
            self.state.update(connection='Simulation ready',detail='Generating motion windows; inference runs on this laptop.');self.started=time.time()
        while not self.stop.is_set() and revision==self.revision:
            mass=settings['grams'] if settings['mode']=='manual' else (6. if (window//6)%2==0 else 55.)
            rpm=settings['rpm'];t,z=simulate(rng,mass,rpm)
            with self.lock:self.state['simulated_mass_g']=mass
            for i in range(0,N,4):
                if revision!=self.revision or self.stop.is_set():return
                elapsed=time.monotonic()-start
                with self.lock:
                    self.state.update(pressure_psi=(93500+30*math.sin(elapsed/20))/PA_PER_PSI,temperature_c=27+.2*math.sin(elapsed/15),humidity_pct=48+math.sin(elapsed/18),gx=0.,gy=0.,windows=window,truth='synthetic_input',run_id='simulation')
                packet=dict(device_ms=int(elapsed*1000),ax=3.2+math.sin(2*math.pi*rpm/60*t[i]),ay=math.cos(2*math.pi*rpm/60*t[i]),az=float(z[i]),gz=rpm*6,score=previous,rpm=rpm,state=previous_state,seq=seq%65536)
                self.publish(packet,revision);seq+=1;await asyncio.sleep(4/FS)
            previous=self.model.predict(features(z,rpm/60,t));previous_state=classify(previous);window+=1
    async def live(self,revision,settings):
        try:from bleak import BleakScanner,BleakClient
        except ImportError:
            self.issue('BLE_NOT_INSTALLED','Bluetooth dependency is missing.','Run SETUP_WINDOWS.bat, then restart START_DEMO.bat.');return
        while revision==self.revision and not self.stop.is_set():
            try:
                with self.lock:self.state.update(connection='Scanning',stream='Waiting for board',label='Searching',score=None);self.started=time.time()
                found=await BleakScanner.discover(timeout=5,return_adv=True)
                candidates=[device for device,adv in found.values() if (adv.local_name or device.name) in ('TyreLabRev2','TyreTinyML') or SERVICE in [u.lower() for u in adv.service_uuids]]
                if self.address:candidates=[device for device,adv in found.values() if device.address.lower()==self.address.lower()]
                if not candidates:raise RuntimeError('NO_BOARD|No TyreLab board found.|Power the Arduino, enable Bluetooth, bring it closer and close other BLE apps.')
                if len(candidates)>1:raise RuntimeError('MULTIPLE_BOARDS|More than one TyreLab board found.|Turn off other boards or launch app.py with --address and the correct BLE address.')
                with self.lock:self.state.update(connection='Connecting',detail='Opening Bluetooth service.');self.clear('NO_BOARD','BLE_CONNECTION')
                async with BleakClient(candidates[0],timeout=15) as client:
                    if client.services.get_characteristic(ENVIRONMENT) is None:raise RuntimeError('OLD_FIRMWARE|Board has the old firmware without environment telemetry.|Upload the final TyreLabRev2.ino once; your friend will then need no code changes.')
                    with self.lock:
                        self.last_seq=None;self.last_env=None;self.state.update(connection='Connected',stream='Waiting for readings',model_verified=False,label='Checking model',score=None);self.started=time.time();self.clear('OLD_FIRMWARE','NO_BOARD','BLE_CONNECTION','BLUETOOTH_OFF')
                    def motion_cb(_,data):
                        if revision!=self.revision:return
                        try:self.publish(decode_motion(data),revision);self.clear('MOTION_PACKET')
                        except ValueError as exc:self.issue('MOTION_PACKET',str(exc),'Upload final firmware; reconnect.')
                    def env_cb(_,data):self.consume_environment(data,revision)
                    self.consume_environment(await client.read_gatt_char(ENVIRONMENT),revision)
                    await client.start_notify(ENVIRONMENT,env_cb);await client.start_notify(MOTION,motion_cb)
                    while client.is_connected and revision==self.revision and not self.stop.is_set():await asyncio.sleep(.2)
                    if revision!=self.revision or self.stop.is_set():return
                    raise RuntimeError('BLE_CONNECTION|Arduino Bluetooth connection was lost.|Keep board close and powered. Reconnection is automatic.')
            except asyncio.CancelledError:raise
            except Exception as exc:
                if revision!=self.revision:return
                message=str(exc);parts=message.split('|',2)
                if len(parts)==3:code,msg,fix=parts
                else:
                    code='BLUETOOTH_OFF' if any(s in message.lower() for s in ('powered off','not available','radio','bluetooth is turned off')) else 'BLE_CONNECTION'
                    msg='Bluetooth error: '+message;fix='Enable Bluetooth; close apps using this board; power-cycle Arduino. The app retries automatically.'
                self.issue(code,msg,fix)
                with self.lock:self.state.update(connection='Retrying',stream='Disconnected',label='Disconnected',score=None,model_verified=False,pressure_psi=None,temperature_c=None,humidity_pct=None)
                await asyncio.sleep(2)
    async def run(self):
        while not self.stop.is_set():
            with self.lock:revision=self.revision;settings=dict(self.settings)
            task=asyncio.create_task(self.live(revision,settings) if settings['mode']=='live' else self.synthetic(revision,settings))
            try:
                while revision==self.revision and not self.stop.is_set() and not task.done():await asyncio.sleep(.05)
                if not task.done():task.cancel()
                try:await task
                except asyncio.CancelledError:pass
                except Exception as exc:self.issue('WORKER_FAILURE',str(exc),'Restart START_DEMO.bat; inspect logs/diagnostics.log.')
                # Don't respawn a terminal task in a busy loop; wait for user mode change.
                if revision==self.revision:
                    while revision==self.revision and not self.stop.is_set():await asyncio.sleep(.1)
            finally:
                if not task.done():task.cancel()
    def close(self):self.fp.flush();self.fp.close()

class Handler(BaseHTTPRequestHandler):
    engine=None
    def log_message(self,*args):pass
    def respond(self,data,status=200,kind='application/json'):
        payload=data if isinstance(data,bytes) else json.dumps(data,allow_nan=False).encode()
        self.send_response(status);self.send_header('Content-Type',kind);self.send_header('Content-Length',str(len(payload)));self.send_header('Cache-Control','no-store');self.end_headers()
        try:self.wfile.write(payload)
        except (BrokenPipeError,ConnectionResetError):pass
    def do_GET(self):
        path=self.path.split('?',1)[0]
        try:
            if path=='/api/state':return self.respond(self.engine.snapshot())
            if path in ('/','/app.js','/style.css'):
                file={'/':'index.html','/app.js':'app.js','/style.css':'style.css'}[path];kind={'/':'text/html; charset=utf-8','/app.js':'text/javascript','/style.css':'text/css'}[path]
                return self.respond((ROOT/'static'/file).read_bytes(),kind=kind)
            if path=='/api/log':
                with self.engine.lock:self.engine.fp.flush();payload=self.engine.log_path.read_bytes()
                return self.respond(payload,kind='text/csv; charset=utf-8')
            self.respond({'error':'Route not found'},404)
        except Exception as exc:logging.exception('GET failed');self.respond({'error':str(exc)},500)
    def do_POST(self):
        try:
            # Accept local dashboard origins only; do not permit foreign websites to control modes.
            origin=self.headers.get('Origin','')
            if origin and origin not in (f'http://127.0.0.1:{self.server.server_port}',f'http://localhost:{self.server.server_port}'):return self.respond({'error':'Only the local dashboard may control this app.'},403)
            length=int(self.headers.get('Content-Length',0))
            if not 0<length<=2048:raise ValueError('Invalid request size')
            body=json.loads(self.rfile.read(length))
            if not isinstance(body,dict):raise ValueError('Request must be a JSON object')
            if self.path=='/api/control':return self.respond({'ok':True,'settings':self.engine.configure(body)})
            if self.path=='/api/label':self.engine.annotate(body);return self.respond({'ok':True})
            self.respond({'error':'Route not found'},404)
        except (ValueError,TypeError,KeyError) as exc:self.respond({'error':str(exc)},400)
        except Exception as exc:logging.exception('POST failed');self.respond({'error':str(exc)},500)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--port',type=int,default=8000);parser.add_argument('--address');parser.add_argument('--diameter',type=float,default=.6729);parser.add_argument('--no-browser',action='store_true');parser.add_argument('--mode',choices=['live','synthetic','manual'],default='synthetic');args=parser.parse_args()
    if not math.isfinite(args.diameter) or args.diameter<=0:parser.error('diameter must be a positive number in metres')
    engine=None;thread=None;server=None
    try:
        logs=ROOT/'logs';logs.mkdir(exist_ok=True)
        logging.basicConfig(level=logging.WARNING,handlers=[logging.FileHandler(logs/'diagnostics.log',encoding='utf-8'),logging.StreamHandler()])
        model=Model(ROOT/'model.json');report=json.loads((ROOT/'training_report.json').read_text());engine=Engine(model,report,logs,args.diameter,args.address,args.mode)
        Handler.engine=engine;server=ThreadingHTTPServer(('127.0.0.1',args.port),Handler)
        def worker():
            try:asyncio.run(engine.run())
            except Exception as exc:engine.issue('ENGINE_CRASH',str(exc),'Restart START_DEMO.bat; inspect diagnostics.log.')
        thread=threading.Thread(target=worker,daemon=True);thread.start()
        url=f'http://127.0.0.1:{args.port}';print(f'TyreLab dashboard: {url}\nCSV: {engine.log_path}\nKeep this window open. Ctrl+C stops the demo.\nMode selection is on the website.',flush=True)
        if not args.no_browser:webbrowser.open(url)
        try:server.serve_forever()
        except KeyboardInterrupt:print('\nStopping demo...')
    except OSError as exc:
        if getattr(exc,'errno',None) in (48,98,10048):print(f'ERROR PORT_BUSY: Port {args.port} is already in use. Close the other demo window or run app.py --port 8001.',file=sys.stderr)
        else:print(f'ERROR FILE_OR_NETWORK: {exc}. Extract into a writable folder and try again.',file=sys.stderr)
        return 1
    except Exception as exc:print(f'ERROR STARTUP: {exc}. Restore all files from the ZIP and run SETUP_WINDOWS.bat.',file=sys.stderr);return 1
    finally:
        if engine:engine.stop.set()
        if server:server.server_close()
        if thread:thread.join(timeout=20)
        if engine and (thread is None or not thread.is_alive()):engine.close()
    return 0
if __name__=='__main__':sys.exit(main())
