# TyreLab final demo package

Use this package instead of the first ZIP. It fixes the Arduino B1 name collision in both the model header and the training generator.

## The two folders

**01_Arduino_Upload** is for Ritwik. Open TyreLabRev2/TyreLabRev2.ino, install the listed libraries, and upload it once. Keep model.h and features.h alongside the sketch. All three files are needed. Read UPLOAD_AND_TEST.md.

**02_Friend_Demo** is the only folder your friend needs. Copy this complete folder to their Windows laptop. They run SETUP_WINDOWS.bat once, then START_DEMO.bat. They select Live Arduino, Synthetic playback or Manual simulation on the website. They do not touch Arduino code. Read FRIEND_QUICK_START.md.

The pretrained model is included. Training is optional and is kept inside the Arduino folder, away from your friend's operating files.

## What the website shows

- Live Arduino: physical IMU readings and predictions from the onboard neural network; ambient pressure in PSI, near-board temperature in degrees C and relative humidity. The grams slider is hidden.
- Synthetic playback: generated input alternates between 6 g residual imbalance and 55 g test imbalance; the laptop runs the same exported model and preprocessing. No Arduino is required.
- Manual simulation: choose 0–100 g on the slider and simulation RPM. The laptop generates the signal and runs the same model. The slider does not force a prediction. Masses outside the training simulator's normal/abnormal ranges are exploratory.

Pressure is explicitly **ambient absolute pressure around the board**. Nano 33 BLE Sense Rev2 does have an LPS22HB barometer, but a sensor mounted on the exposed rim does not measure tyre inflation pressure. It is limited to 260–1260 hPa (about 3.77–18.28 PSI absolute). Do not place the board inside an inflated tyre as a substitute for a tyre-pressure transducer. Temperature is local to the board; it is not tyre-core/internal air temperature.

## Before the demo

1. Test the friend's setup using laptop synthetic playback.
2. Upload the final firmware once and select Live Arduino on the website. Confirm Connected, Receiving data and Matches laptop model.
3. With the board stationary, expect Too slow. Confirm pressure and temperature cards fill after a couple of seconds.
4. Mount the board face parallel to the wheel plane, so Z points along the axle. Secure the board, battery and wires. Keep the guard in place.
5. Spin steadily around 120 RPM, within 78–162 RPM. Allow at least 6 seconds to settle. Test baseline and the secured50–60 g weight at matched speeds.
6. Follow the physical test instructions before claiming any real-world accuracy.

Synthetic binary test accuracy is 94.03%. With the deployed uncertain band counted as failures, synthetic decision success is 83.89%. Physical accuracy remains unknown. Software cannot guarantee that a rigid freely spinning wheel produces enough axial motion from a 50–60 g imbalance. The installed board/battery mass must be included in the baseline and counterbalanced.

## Checks and remaining limits

TEST_RESULTS.md records the software checks. The firmware was syntax-checked on a host compiler with Arduino API stubs, including Arduino's B1 symbol, and the actual C++ feature extractor/model were compared against Python. This is not a full Arduino Mbed core compile or a physical BLE test. The testing browser blocked localhost, so the dashboard's actual HTML/JS controls were checked with a local DOM contract test rather than a visual browser pass.

You must still upload and test on the real Nano. Bluetooth adapter behaviour on your friend's Windows laptop and actual imbalance detection need their physical checks.
