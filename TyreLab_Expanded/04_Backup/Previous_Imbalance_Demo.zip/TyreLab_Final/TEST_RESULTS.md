# Verification results

Passed: firmware host syntax with Arduino B1 symbol; compiled C++ features/model parity (maximum score difference 9.89e-8); BLE packet units; old firmware rejection; stale data and model mismatch handling; HTTP server, synthetic inference, mode switching, static assets and CSV; dashboard control contract including hidden live slider; BLE worker with mocked adapter.

Not verified: full Arduino Mbed core compilation, actual sensors, physical Windows Bluetooth or visual browser rendering. Real-world accuracy is unmeasured.

Binary synthetic accuracy 94.03%. Deployed rule counting uncertain results as wrong: 83.89%.
