"""Parity, packet, engine and HTTP tests. No physical accuracy claim."""
import asyncio,csv,importlib.util,json,os,struct,subprocess,sys,tempfile,time,urllib.request,urllib.error
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[2];DEMO=ROOT/'02_Friend_Demo';ARDUINO=ROOT/'01_Arduino_Upload/TyreLabRev2'
sys.path.insert(0,str(DEMO))
from ml import Model,features,simulate,classify
from protocol import decode_motion,decode_environment,PA_PER_PSI
from app import Engine
model=Model(DEMO/'model.json');report=json.loads((DEMO/'training_report.json').read_text())
# Model header includes namespace and renamed biases, and is safe with Arduino Binary enum.
with tempfile.TemporaryDirectory() as td:
    temp=Path(td);source=temp/'parity.cpp';exe=temp/'parity'
    source.write_text('#include <iostream>\nenum { B1=1 };\n#include "'+str(ARDUINO/'model.h')+'"\n#include "'+str(ARDUINO/'features.h')+'"\nint main(){float z[256],t[256],f,x[6];std::cin>>f;for(int i=0;i<256;i++)std::cin>>t[i]>>z[i];tyrelab::extractFeatures(z,t,256,f,x);std::cout.precision(9);for(int i=0;i<6;i++)std::cout<<x[i]<<" ";std::cout<<tyrelab::infer(x)<<"\\n";}')
    subprocess.run(['g++','-std=c++11',str(source),'-o',str(exe)],check=True)
    rng=np.random.default_rng(11);maximum=0
    for mass,rpm in [(0,90),(6,120),(55,120),(100,150)]:
        t,z=simulate(rng,mass,rpm);f=rpm/60
        payload=str(f)+'\n'+'\n'.join(f'{a} {b}' for a,b in zip(t,z))
        out=subprocess.run([str(exe)],input=payload,text=True,capture_output=True,check=True)
        actual=np.array(list(map(float,out.stdout.split())));expected=features(z,f,t)
        assert np.allclose(actual[:6],expected,rtol=2e-5,atol=2e-6),(actual,expected)
        err=abs(actual[6]-model.predict(expected));maximum=max(maximum,err);assert err<2e-5
    print('Actual compiled C++ preprocessing+model parity passed; maximum score error',maximum)
    subprocess.run([sys.executable,str(Path(__file__).with_name('check_firmware.py'))],check=True)
# Packet contracts, sentinels, old firmware rejection and environment units.
motion=struct.pack('<IhhhhHHBBH',1000,1200,-200,5,7200,8000,1200,2,3,9)
packet=decode_motion(motion);assert packet['ax']==1.2 and packet['rpm']==120
old=bytearray(motion);old[17]=1
try:decode_motion(old);raise AssertionError('Old firmware accepted')
except ValueError:pass
env=struct.pack('<IhHhhHHI',101325,2750,4800,0,0,1,0,model.fingerprint)
values=decode_environment(env);assert abs(values['pressure_psi']-14.69595)<.0001 and values['temperature_c']==27.5
missing=struct.pack('<IhHhhHHI',0,-32768,65535,0,0,0,12,model.fingerprint)
assert decode_environment(missing)['pressure_psi'] is None
# Engine revision guards, sensor faults and mismatch/stale handling.
with tempfile.TemporaryDirectory() as td:
    engine=Engine(model,report,Path(td),default_mode='live');engine.consume_environment(env,0);assert engine.state['model_verified']
    engine.publish(packet,0);assert engine.state['label']=='Unbalanced';assert engine.state['score']==.8
    engine.consume_environment(missing,0);assert 'PRESSURE_INIT' in engine.issues and 'TEMPERATURE_INIT' in engine.issues
    bad=struct.pack('<IhHhhHHI',101325,2750,4800,0,0,1,0,model.fingerprint+1);engine.consume_environment(bad,0)
    packet['seq']=10;engine.publish(packet,0);assert engine.snapshot()['state']['score'] is None and 'MODEL_MISMATCH' in engine.issues
    engine.configure({'mode':'manual','grams':100});before=engine.state['received'];engine.publish(packet,0);assert engine.state['received']==before
    assert engine.snapshot()['settings']['mode']=='manual'
    for body in ({'grams':101},{'grams':float('nan')},{'mode':'fake'}):
        try:engine.configure(body);raise AssertionError('Invalid settings accepted')
        except ValueError:pass
    engine.configure({'mode':'live'});revision=engine.revision;engine.consume_environment(env,revision);packet['seq']=1;engine.publish(packet,revision);engine.state['last_seen']=time.time()-3
    assert engine.snapshot()['state']['label']=='Data stale' and engine.snapshot()['state']['score'] is None
    engine.close()
print('Packet units, old-firmware rejection, model mismatch, stale readings and mode revision guards passed')
# Browser-facing HTTP integration, with a real producer process and mode controls.
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
proc=subprocess.Popen([sys.executable,str(DEMO/'app.py'),'--no-browser','--port','8151'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
def request(path,body=None):
    req=urllib.request.Request('http://127.0.0.1:8151'+path,data=json.dumps(body).encode() if body is not None else None,headers={'Content-Type':'application/json'})
    with opener.open(req,timeout=3) as response:return json.load(response)
try:
    for _ in range(100):
        if proc.poll() is not None:raise RuntimeError(proc.stdout.read())
        try:
            data=request('/api/state')
            if data['state']['received']>5:break
        except OSError:pass
        time.sleep(.1)
    else:raise AssertionError('Server did not start')
    assert data['state']['mode']=='synthetic'
    request('/api/control',{'mode':'manual','grams':60,'rpm':120});time.sleep(.3);data=request('/api/state');assert data['settings']['grams']==60 and data['state']['mode']=='manual'
    request('/api/control',{'mode':'live'});time.sleep(.3);data=request('/api/state');assert data['state']['mode']=='live' and data['state']['score'] is None and not data['history']
    request('/api/control',{'mode':'synthetic'});time.sleep(.4);data=request('/api/state');assert data['state']['mode']=='synthetic' and data['state']['received']>0
    # Give one window enough time to complete; score comes from real exported model.
    time.sleep(3);data=request('/api/state');assert data['state']['score'] is not None
    for path in ('/','/style.css','/app.js','/api/log'):
        with opener.open('http://127.0.0.1:8151'+path,timeout=3) as response:assert response.status==200 and response.read()
    print('Real HTTP server, synthetic inference, mode switching, cancellation, static assets and CSV download passed')
    # UI contract tests use actual HTML and JS with a minimal DOM; browser localhost is blocked in this environment.
    subprocess.run(['node',str(Path(__file__).with_name('test_ui.cjs'))],check=True)
finally:
    proc.terminate();proc.wait(timeout=5)
print('ALL SOFTWARE CHECKS PASSED. Arduino-core compilation, actual BLE and physical accuracy are not established by these tests.')
