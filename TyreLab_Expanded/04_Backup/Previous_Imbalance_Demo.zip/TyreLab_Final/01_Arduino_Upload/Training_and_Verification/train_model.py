"""Synthetic-only training. No physical accuracy claim. Recreates model.h + model.json."""
from pathlib import Path
import json, csv
import numpy as np
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, balanced_accuracy_score, confusion_matrix
ROOT=Path(__file__).resolve().parent
DEMO=ROOT.parent.parent/'02_Friend_Demo'
ARDUINO=ROOT.parent/'TyreLabRev2'
FS=99.84; N=256

def features(z, f, t=None):
    t=np.arange(len(z))/FS if t is None else np.asarray(t)
    q=np.asarray(z)-np.mean(z); c=np.cos(2*np.pi*f*t); s=np.sin(2*np.pi*f*t)
    c-=c.mean(); s-=s.mean()
    cc=c@c; ss=s@s; cs=c@s; det=max(cc*ss-cs*cs,1e-12)
    a=((q@c)*ss-(q@s)*cs)/det; b=((q@s)*cc-(q@c)*cs)/det
    amp=np.hypot(a,b); rms=np.sqrt(np.mean(q*q)); residual=q-a*c-b*s
    rr=np.sqrt(np.mean(residual*residual)); scale=max(f*f,0.25)
    return np.array([rms/scale,amp/scale,rr/scale,amp/(rms+1e-6),np.max(np.abs(q))/(rms+1e-6),f])

def waveform(rng,label,f,transfer,leak,noise):
    t=np.arange(N)/FS
    mass=rng.uniform(50,60) if label else rng.uniform(0,12)
    phase=rng.uniform(0,2*np.pi)
    # Assumed axial response, NOT a measured wheel/stand transfer function.
    # Rotating sensor can see two-per-revolution motion; include both harmonics.
    amp=mass*transfer*f*f
    z=(leak*np.sin(2*np.pi*f*t+rng.uniform(0,6.28))
       +amp*np.sin(2*np.pi*f*t+phase)
       +rng.uniform(.05,.4)*amp*np.sin(4*np.pi*f*t+phase)
       +rng.normal(0,noise,N)
       +rng.uniform(.0005,.004)*np.sin(2*np.pi*rng.uniform(12,35)*t+phase))
    return z

def predict(x,model):
    x=(np.asarray(x)-model['mean'])/model['scale']
    h=np.maximum(0,x@np.asarray(model['w1'])+model['b1'])
    score=h@np.asarray(model['w2'])+model['b2']
    return 1/(1+np.exp(-np.clip(score,-50,50)))

def main():
    rng=np.random.default_rng(20261005); X=[]; Y=[]; groups=[]
    # Separate entire simulated rigs, not overlapping windows, into train/test.
    for rig in range(300):
        transfer=np.exp(rng.uniform(np.log(.00007),np.log(.00035)))
        leak=rng.uniform(.0005,.009); noise=rng.uniform(.0008,.004)
        for label in (0,1):
            for _ in range(12):
                f=rng.uniform(1.3,2.7)
                z=waveform(rng,label,f,transfer,leak,noise)
                X.append(features(z,f)); Y.append(label); groups.append(rig)
    X=np.asarray(X); Y=np.asarray(Y); groups=np.asarray(groups)
    train=groups<240; test=~train
    scaler=StandardScaler().fit(X[train]); net=MLPClassifier(hidden_layer_sizes=(8,),activation='relu',max_iter=500,random_state=7,early_stopping=True,validation_fraction=.15)
    net.fit(scaler.transform(X[train]),Y[train])
    pred=net.predict(scaler.transform(X[test]))
    model={'mean':scaler.mean_.tolist(),'scale':scaler.scale_.tolist(),'w1':net.coefs_[0].tolist(),'b1':net.intercepts_[0].tolist(),'w2':net.coefs_[1][:,0].tolist(),'b2':float(net.intercepts_[1][0]),'sample_rate':FS,'window':N,'training':'synthetic only','valid_hz':[1.3,2.7]}
    import hashlib, struct
    values=np.concatenate([scaler.mean_,scaler.scale_,net.coefs_[0].ravel(),net.intercepts_[0],net.coefs_[1].ravel(),net.intercepts_[1]])
    fingerprint=int.from_bytes(hashlib.sha256(values.astype('<f4').tobytes()).digest()[:4],'little')
    model['fingerprint']=fingerprint
    report={'synthetic_test_accuracy':float(accuracy_score(Y[test],pred)),'synthetic_balanced_accuracy':float(balanced_accuracy_score(Y[test],pred)),'confusion_matrix_rows_true_normal_unbalanced':confusion_matrix(Y[test],pred).tolist(),'train_windows':int(train.sum()),'test_windows':int(test.sum()),'split':'240 simulated rigs train / 60 unseen simulated rigs test','real_world_accuracy':None,'assumptions':'Axial transfer and mounting leakage are assumed, not measured. Synthetic accuracy is conditional on this simulator.'}
    scores=predict(X[test],model)
    decisions=np.where(scores>=.65,1,np.where(scores<=.35,0,-1))
    report['synthetic_deployed_rule_accuracy_abstentions_count_wrong']=float(np.mean(decisions==Y[test]))
    report['synthetic_deployed_rule_coverage']=float(np.mean(decisions!=-1))
    (DEMO/'model.json').write_text(json.dumps(model,indent=2))
    (DEMO/'training_report.json').write_text(json.dumps(report,indent=2))
    with (ROOT/'synthetic_features.csv').open('w',newline='') as fp:
        writer=csv.writer(fp); writer.writerow(['rig','split','label','rms_f2','harmonic_f2','residual_f2','harmonic_ratio','crest','rotation_hz'])
        for g,y,x in zip(groups,Y,X): writer.writerow([g,'train' if g<240 else 'test',y,*x])
    def vec(v): return '{'+','.join(f'{float(i):.9e}f' for i in v)+'}'
    header='#pragma once\n#include <math.h>\nnamespace tyrelab {\n'
    for name,v in [('MODEL_MEAN',model['mean']),('MODEL_SCALE',model['scale']),('MODEL_HIDDEN_BIAS',model['b1']),('MODEL_OUTPUT_WEIGHTS',model['w2'])]: header+=f'const float {name}[{len(v)}] = {vec(v)};\n'
    header+=f'const unsigned long MODEL_ID = {fingerprint}UL;\n'
    header+='const float MODEL_INPUT_WEIGHTS[6][8] = {'+','.join(vec(row) for row in model['w1'])+'};\n'
    header+=f'const float MODEL_OUTPUT_BIAS = {model["b2"]:.9e}f;\n'
    header+='inline float infer(const float *x) { float o=MODEL_OUTPUT_BIAS; for(int j=0;j<8;j++){ float h=MODEL_HIDDEN_BIAS[j]; for(int i=0;i<6;i++) h+=(x[i]-MODEL_MEAN[i])/MODEL_SCALE[i]*MODEL_INPUT_WEIGHTS[i][j]; o+=fmaxf(0,h)*MODEL_OUTPUT_WEIGHTS[j]; } return 1.0f/(1.0f+expf(-fmaxf(-50,fminf(50,o)))); }\n'
    header+='} // namespace tyrelab\n'
    (ARDUINO/'model.h').write_text(header)
    parity=np.max(np.abs(predict(X[test],model)-net.predict_proba(scaler.transform(X[test]))[:,1]))
    assert parity<1e-9
    print(json.dumps(report,indent=2)); print('Export parity error:',parity)
if __name__=='__main__': main()
