"""Tests real BLE-control code using a simulated adapter, not actual radio hardware."""
import asyncio,json,struct,sys,tempfile,types
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'02_Friend_Demo'))
from app import Engine
from ml import Model
from protocol import SERVICE,MOTION,ENVIRONMENT
model=Model(ROOT/'02_Friend_Demo/model.json');report=json.loads((ROOT/'02_Friend_Demo/training_report.json').read_text())
instances=[]
class Scanner:
    @classmethod
    async def discover(cls,**kwargs):
        await asyncio.sleep(.01)
        return {'AA:BB':(types.SimpleNamespace(address='AA:BB',name='TyreLabRev2'),types.SimpleNamespace(local_name='TyreLabRev2',service_uuids=[SERVICE]))}
class Client:
    def __init__(self,*args,**kwargs):
        self.is_connected=False;self.callbacks={};self.pulse=None;self.closed=False;instances.append(self)
        self.services=types.SimpleNamespace(get_characteristic=lambda uuid:True)
    async def __aenter__(self):self.is_connected=True;self.pulse=asyncio.create_task(self.emit());return self
    async def __aexit__(self,*args):
        self.is_connected=False;self.closed=True;self.pulse.cancel()
        try:await self.pulse
        except asyncio.CancelledError:pass
    async def read_gatt_char(self,uuid):return struct.pack('<IhHhhHHI',93500,2700,4800,0,0,1,0,model.fingerprint)
    async def start_notify(self,uuid,callback):self.callbacks[uuid]=callback
    async def emit(self):
        seq=0
        while self.is_connected:
            if ENVIRONMENT in self.callbacks:self.callbacks[ENVIRONMENT](None,await self.read_gatt_char(ENVIRONMENT))
            if MOTION in self.callbacks:self.callbacks[MOTION](None,struct.pack('<IhhhhHHBBH',seq*40,3200,0,10,7200,8000,1200,2,3,seq%65536));seq+=1
            await asyncio.sleep(.04)
async def main():
    sys.modules['bleak']=types.SimpleNamespace(BleakClient=Client,BleakScanner=Scanner)
    with tempfile.TemporaryDirectory() as td:
        engine=Engine(model,report,Path(td),default_mode='live');task=asyncio.create_task(engine.run())
        try:
            await asyncio.sleep(.35);s=engine.snapshot()['state'];assert s['connection']=='Connected' and s['stream']=='Receiving data' and s['model_verified'] and s['label']=='Unbalanced';assert s['pressure_psi'] is not None
            engine.configure({'mode':'manual','grams':30});await asyncio.sleep(.2)
            assert instances[0].closed,'BLE session was not closed after switch'
            assert engine.state['mode']=='manual' and engine.state['received']>0
            engine.configure({'mode':'live'});await asyncio.sleep(.3)
            assert len(instances)==2 and engine.state['connection']=='Connected'
        finally:engine.stop.set();await task;engine.close()
    print('Real BLE worker exercised with mocked adapter: connection, notifications, environment/model handshake and disconnect/reconnect on mode switch passed.')
asyncio.run(main())
