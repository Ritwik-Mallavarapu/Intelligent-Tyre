#pragma once
#include <math.h>
namespace tyrelab {
// Identical feature definitions to ml.py; Z acceleration is in g, time in seconds.
inline void extractFeatures(const float* z, const float* t, int n, float f, float* x) {
  float c[256],s[256],mean=0,cm=0,sm=0;
  for(int i=0;i<n;i++){mean+=z[i];c[i]=cosf(6.28318530718f*f*t[i]);s[i]=sinf(6.28318530718f*f*t[i]);cm+=c[i];sm+=s[i];}
  mean/=n;cm/=n;sm/=n;
  float cc=0,ss=0,cs=0,qc=0,qs=0,energy=0,peak=0;
  for(int i=0;i<n;i++){c[i]-=cm;s[i]-=sm;float q=z[i]-mean;cc+=c[i]*c[i];ss+=s[i]*s[i];cs+=c[i]*s[i];qc+=q*c[i];qs+=q*s[i];energy+=q*q;peak=fmaxf(peak,fabsf(q));}
  float det=fmaxf(cc*ss-cs*cs,1e-12f),a=(qc*ss-qs*cs)/det,b=(qs*cc-qc*cs)/det,residual=0;
  for(int i=0;i<n;i++){float q=z[i]-mean-a*c[i]-b*s[i];residual+=q*q;}
  float rms=sqrtf(energy/n),amp=sqrtf(a*a+b*b),scale=fmaxf(f*f,.25f);
  x[0]=rms/scale;x[1]=amp/scale;x[2]=sqrtf(residual/n)/scale;x[3]=amp/(rms+1e-6f);x[4]=peak/(rms+1e-6f);x[5]=f;
}
}
