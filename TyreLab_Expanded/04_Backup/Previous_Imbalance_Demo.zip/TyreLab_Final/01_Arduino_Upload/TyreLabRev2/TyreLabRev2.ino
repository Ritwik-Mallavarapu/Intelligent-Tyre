#include <ArduinoBLE.h>
#include <Arduino_BMI270_BMM150.h>
#include <Wire.h>
#include "model.h"
#include "features.h"
// Upload once. Laptop mode selection never requires changing this firmware.
// Mount broad face parallel to wheel plane: Z along axle.
const int WINDOW_SIZE=256;
const char* TL_SERVICE="7b110001-89ab-4cde-9012-34567890abcd";
BLEService tlService(TL_SERVICE);
BLECharacteristic tlMotion("7b110002-89ab-4cde-9012-34567890abcd",BLERead|BLENotify,20,true);
BLECharacteristic tlEnvironment("7b110003-89ab-4cde-9012-34567890abcd",BLERead|BLENotify,20,true);
float samples[WINDOW_SIZE],rotations[WINDOW_SIZE],times[WINDOW_SIZE];
float ax=0,ay=0,az=0,gx=0,gy=0,gz=0,modelScore=.5f;
int sampleCount=0;uint16_t packetSequence=0,windowSequence=0;
uint8_t detectionState=0;
uint16_t startupFaults=0,runtimeFaults=0;
bool imuOK=false,rangeOK=false,baroOK=false,hsOK=false,windowClip=false,windowTiming=false;
uint32_t windowStart=0,lastSample=0,lastMotion=0,lastEnvironment=0;
uint32_t pressurePa=0;int16_t temperatureCenti=-32768;uint16_t humidityCenti=65535;
uint8_t baroAddress=0x5c;bool hsPending=false;uint32_t hsRequested=0,hsLast=0;
// Fault bits:1 IMU init,2 range16g,4 pressure init,8 HS3003 init,
//16 pressure invalid,32 temperature invalid,64 radial-axis clipping.
// States:0 warmup,1 normal,2 unbalanced,3 uncertain,4 slow,5 fast,6 clip,
//7 unstable,8 irregular sampling,9 IMU failure,10 mount orientation.
bool writeRegister(uint8_t address,uint8_t reg,uint8_t value){
  Wire1.beginTransmission(address);Wire1.write(reg);Wire1.write(value);return Wire1.endTransmission()==0;
}
bool readRegisters(uint8_t address,uint8_t reg,uint8_t* data,int n){
  Wire1.beginTransmission(address);Wire1.write(reg);
  if(Wire1.endTransmission(false)!=0)return false;
  if(Wire1.requestFrom(address,(uint8_t)n)!=(uint8_t)n)return false;
  for(int i=0;i<n;i++)data[i]=(uint8_t)Wire1.read();return true;
}
bool configureRange(){
  uint8_t v=0;if(!writeRegister(0x68,0x41,3))return false;delay(5);
  return readRegisters(0x68,0x41,&v,1)&&(v&3)==3;
}
bool startHS(){Wire1.beginTransmission(0x44);return Wire1.endTransmission()==0;}
void initializeEnvironment(){
  uint8_t id=0;
  if(!(readRegisters(0x5c,0x0f,&id,1)&&id==0xb1)){
    baroAddress=0x5d;id=0;
  }
  baroOK=readRegisters(baroAddress,0x0f,&id,1)&&id==0xb1;
  // LPS22HB: continuous1Hz, BDU on; register auto-increment on.
  if(baroOK)baroOK=writeRegister(baroAddress,0x11,0x10)&&writeRegister(baroAddress,0x10,0x12);
  if(!baroOK)startupFaults|=4;
  hsOK=startHS();if(!hsOK)startupFaults|=8;
  if(hsOK){hsPending=true;hsRequested=millis();}
}
void pollEnvironment(){
  uint32_t now=millis();
  // Split HS3003 request/read so its conversion does NOT block IMU sampling.
  if(hsOK && hsPending && (uint32_t)(now-hsRequested)>=50){
    hsPending=false;
    uint8_t b[4];bool ok=Wire1.requestFrom((uint8_t)0x44,(uint8_t)4)==4;
    if(ok)for(int i=0;i<4;i++)b[i]=(uint8_t)Wire1.read();
    if(ok && (b[0]>>6)==0){
      uint16_t rh=((uint16_t)(b[0]&0x3f)<<8)|b[1];
      uint16_t rt=(((uint16_t)b[2]<<8)|b[3])>>2;
      float temp=rt*165.0f/16383.0f-40.0f,humidity=rh*100.0f/16383.0f;
      if(isfinite(temp)&&temp>=-40&&temp<=125){temperatureCenti=(int16_t)roundf(temp*100);humidityCenti=(uint16_t)roundf(humidity*100);runtimeFaults&=~32;}
      else{temperatureCenti=-32768;humidityCenti=65535;runtimeFaults|=32;}
    }else{temperatureCenti=-32768;humidityCenti=65535;runtimeFaults|=32;}
    hsLast=now;
  }
  if(hsOK&&!hsPending&&(uint32_t)(now-hsLast)>=1000){
    hsPending=startHS();hsRequested=now;if(!hsPending){runtimeFaults|=32;hsLast=now;temperatureCenti=-32768;humidityCenti=65535;}
  }
  if((uint32_t)(now-lastEnvironment)<1000)return;lastEnvironment=now;
  if(baroOK){
    uint8_t b[3];if(readRegisters(baroAddress,0x28,b,3)){
      uint32_t raw=(uint32_t)b[0]|((uint32_t)b[1]<<8)|((uint32_t)b[2]<<16);
      float pa=raw*(100.0f/4096.0f);
      if(pa>=26000&&pa<=126000){pressurePa=(uint32_t)roundf(pa);runtimeFaults&=~16;}else{pressurePa=0;runtimeFaults|=16;}
    }else{pressurePa=0;runtimeFaults|=16;}
  }
}
void put16(uint8_t* p,uint16_t value){p[0]=value&255;p[1]=value>>8;}
void put32(uint8_t* p,uint32_t value){for(int i=0;i<4;i++)p[i]=(value>>(8*i))&255;}
void emitEnvironment(){
  uint8_t p[20];put32(p,pressurePa);put16(p+4,(uint16_t)temperatureCenti);put16(p+6,humidityCenti);
  put16(p+8,(uint16_t)(int16_t)roundf(gx*10));put16(p+10,(uint16_t)(int16_t)roundf(gy*10));
  put16(p+12,windowSequence);put16(p+14,startupFaults|runtimeFaults);put32(p+16,(uint32_t)tyrelab::MODEL_ID);
  tlEnvironment.writeValue(p,20);
}
void emitMotion(){
  uint8_t p[20];put32(p,millis());
  put16(p+4,(uint16_t)(int16_t)roundf(ax*1000));put16(p+6,(uint16_t)(int16_t)roundf(ay*1000));put16(p+8,(uint16_t)(int16_t)roundf(az*1000));
  put16(p+10,(uint16_t)(int16_t)roundf(gz*10));put16(p+12,(uint16_t)roundf(modelScore*10000));
  put16(p+14,(uint16_t)roundf(fabsf(gz)/6*10));p[16]=detectionState;p[17]=3;put16(p+18,packetSequence++);
  tlMotion.writeValue(p,20);
}
void classifyWindow(){
  windowSequence++;
  float f=0;for(int i=0;i<WINDOW_SIZE;i++)f+=rotations[i];f/=WINDOW_SIZE;
  float variance=0;for(int i=0;i<WINDOW_SIZE;i++)variance+=(rotations[i]-f)*(rotations[i]-f);
  float totalGyro=sqrtf(gx*gx+gy*gy+gz*gz);
  if(totalGyro>200 && fabsf(gz)<.9f*totalGyro){detectionState=10;return;}
  if(windowClip){detectionState=6;return;}if(windowTiming){detectionState=8;return;}
  if(f<1.3f){detectionState=4;return;}if(f>2.7f){detectionState=5;return;}
  if(sqrtf(variance/WINDOW_SIZE)/f>.05f){detectionState=7;return;}
  float x[6];tyrelab::extractFeatures(samples,times,WINDOW_SIZE,f,x);modelScore=tyrelab::infer(x);
  detectionState=modelScore>=.65f?2:(modelScore<=.35f?1:3);
  if(Serial){Serial.print("RPM=");Serial.print(f*60);Serial.print(" score=");Serial.print(modelScore);Serial.print(" state=");Serial.println(detectionState);}
}
void setup(){
  Serial.begin(115200);pinMode(LED_BUILTIN,OUTPUT);
  // Battery operation starts without waiting for USB.
  if(!BLE.begin()){if(Serial)Serial.println("ERROR BLE_INIT: restart board; check ArduinoBLE/core installation.");while(true){digitalWrite(LED_BUILTIN,!digitalRead(LED_BUILTIN));delay(200);}}
  BLE.setLocalName("TyreLabRev2");BLE.setAdvertisedService(tlService);
  tlService.addCharacteristic(tlMotion);tlService.addCharacteristic(tlEnvironment);BLE.addService(tlService);
  Wire1.begin();imuOK=IMU.begin();if(!imuOK)startupFaults|=1;
  if(imuOK){rangeOK=configureRange();if(!rangeOK)startupFaults|=2;}
  initializeEnvironment();if(!imuOK||!rangeOK)detectionState=9;
  emitEnvironment();emitMotion();BLE.advertise();
  if(Serial)Serial.println("TyreLabRev2 ready; live firmware. Model and sensor fault status available over BLE.");
}
void loop(){
  BLE.poll();pollEnvironment();
  static uint32_t envSent=0;if((uint32_t)(millis()-envSent)>=1000){envSent=millis();emitEnvironment();}
  if(!imuOK||!rangeOK){if((uint32_t)(millis()-lastMotion)>=200){lastMotion=millis();emitMotion();}return;}
  if(IMU.gyroscopeAvailable())IMU.readGyroscope(gx,gy,gz);
  if(!IMU.accelerationAvailable())return;
  if(!IMU.readAcceleration(ax,ay,az))return;
  // Official library divides raw values by8192 (4g); hardware16g requires x4.
  ax*=4;ay*=4;az*=4;
  uint32_t now=micros();if(sampleCount==0){windowStart=now;windowClip=false;windowTiming=false;}
  if(lastSample&&sampleCount>0){uint32_t dt=now-lastSample;if(dt<6000||dt>18000)windowTiming=true;}lastSample=now;
  if(fabsf(az)>15.5f||fabsf(gz)>1950)windowClip=true;
  if(fabsf(ax)>15.5f||fabsf(ay)>15.5f)runtimeFaults|=64;else runtimeFaults&=~64;
  samples[sampleCount]=az;rotations[sampleCount]=fabsf(gz)/360;times[sampleCount]=(uint32_t)(now-windowStart)*1e-6f;sampleCount++;
  if(sampleCount==WINDOW_SIZE){classifyWindow();sampleCount=0;emitEnvironment();}
  static int decimate=0;if(++decimate>=4){decimate=0;emitMotion();}
  digitalWrite(LED_BUILTIN,BLE.connected()?HIGH:LOW);
}
