# Upload once and validate the hardware

## Arduino IDE configuration

1. Install Arduino IDE 2: https://www.arduino.cc/en/software/
2. Boards Manager: install **Arduino Mbed OS Nano Boards**. Your installed 4.6.0 core is the family targeted here.
3. Select **Arduino Nano 33 BLE** under that package, and the USB port. The Sense Rev2 uses the Nano 33 BLE board family.
4. Library Manager: install **ArduinoBLE** and **Arduino_BMI270_BMM150** from Arduino. Do not use Arduino_LSM9DS1; it is for the older sensor.
5. Open **TyreLabRev2/TyreLabRev2.ino**. Its folder must also contain **model.h** and **features.h**. This is a new sketch; do not copy just the old .ino into it.
6. Click Verify, then Upload. If the USB port disappears, double-tap RESET, choose the bootloader port and upload again.
7. Optional Serial Monitor at 115200 shows a window's RPM, score and state after sampling. The firmware starts on battery without waiting for USB.

There is no synthetic/live flag to edit in the sketch. It always reads real sensors and performs onboard inference. Website synthetic modes generate their inputs and evaluate the identical model on the laptop; your friend can switch without uploading firmware.

## What changed to fix compilation

The first model header used B1, which Arduino's Binary.h already defines. The final model parameters are both inside the tyrelab namespace and explicitly named MODEL_HIDDEN_BIAS, MODEL_OUTPUT_BIAS, MODEL_INPUT_WEIGHTS and MODEL_OUTPUT_WEIGHTS. The training generator exports those names too. A host compile check intentionally introduces an Arduino-style B1 enum and verifies no conflict occurs.

## The sensors

- Motion: BMI270 via Arduino_BMI270_BMM150.
- Pressure: onboard LPS22HB barometer. Firmware verifies its identity and configures continuous 1 Hz readings using Wire1. PSI display is Pa/6894.757293168 and is ambient absolute pressure, not tyre gauge pressure.
- Temperature/humidity: onboard HS3003, read using its documented I2C measurement/data-fetch procedure. Firmware triggers conversion, returns to motion sampling, then fetches data after 50 ms. This avoids the blocking measurement wait in a simple sensor example.

No Arduino_LPS22HB or Arduino_HS300x library is required in this sketch: the environment sensor I2C code is included. Wire is supplied by the core. The only extra libraries are ArduinoBLE and Arduino_BMI270_BMM150.

The firmware changes BMI270 ACC_RANGE to 16 g, verifies the register, then multiplies the official library's acceleration results by 4 because its conversion assumes 4 g. If a future library changes that conversion, this correction needs review. This package's code was checked against the official library source. In live mode, a stationary board should show an acceleration magnitude of approximately1 g; this simple sanity check verifies the conversion on your installation. If it shows approximately4 g or0.25 g while stationary, stop and report the library version/output before rotation.

## First check, stationary

Power via USB, start the friend's dashboard, select Live Arduino.

- Within a scan/connect cycle, system status should show Connected and Receiving data.
- Model match should say Matches laptop model.
- Since there is no rotation, Too slow is expected after a full window. No imbalance score is shown outside the supported speed range.
- Temperature/humidity should populate within a couple of seconds. Pressure depends on local altitude; Bangalore may be roughly13.5 PSI absolute, rather than sea-level14.7 PSI. This is not a tyre-pressure reading.
- Motion values continue arriving even if an environment sensor fails; the issue panel explains the sensor fault and leaves its unavailable card blank.

If no board appears, close phone BLE apps, move the laptop closer and restart the board. The final device advertises as TyreLabRev2. The app detects an older TyreTinyML board and explains that it needs this final firmware.

## Mounting and rotation

The board face must be parallel to the wheel plane: Z along the axle. Verify that Z gyroscope is the dominant axis during rotation. RPM=abs(gyro_Z)/6. If X/Y dominates, the dashboard reports Check mounting.

Secure the board/battery bracket near the valve location as planned, but preserve this orientation. A bracket may be needed if the rim surface faces radially. Keep wires fixed and avoid a USB cable to a stationary laptop during rotation. Protect observers with a suitable guard. Do not adjust weights until the wheel fully stops.

Counterbalance board, battery and bracket before using that condition as normal. Leave them installed for both baseline and added-weight tests. A test weight at the centre plane may create mostly radial imbalance and little axial wobble; a freely spinning wheel on a rigid axle can suppress the observable axial signal. Do not loosen the axle or supports to create a signal.

Start at 100–120 RPM, then stay within 78–162 RPM and hold speed steady. With assumed 205/65 R16 geometry this is about 9.9–20.5km/h equivalent. There is no single tyre size for every Creta trim/year: check the actual sidewall. Display conversion defaults to 0.6729m outside diameter; change the laptop command's --diameter if needed. The model uses RPM, so its inference does not depend on this display-only conversion.

The model samples approximately 99.84 Hz and uses 256 samples per window, about 2.56s. BLE transmits motion about 25 Hz and environment about 1 Hz, plus model-window updates. CSV is decimated telemetry, not the full100 Hz training recording.

## Decision states

Normal: score<=0.35. Unbalanced: score>=0.65. Uncertain: intermediate score. The model score is not validated real-world confidence.

The website explains Too slow, Too fast, Sensor clipped, Speed unstable, Sampling irregular, IMU unavailable and Check mounting. It also shows missing environment sensors, stale streams, BLE failures and mismatched model copies. A BLE initialization failure cannot report through BLE; it is printed on Serial and flashes the built-in LED.

## Optional training and verification

Training_and_Verification holds the synthetic datasets, generator and software checks. Your friend does not need it. Training requires numpy and scikit-learn; the script recreates both the Arduino header and the friend's model.json together. It also regenerates the model fingerprint. Re-upload after retraining and give your friend the updated model.json/report.

Source references:
- https://docs.arduino.cc/hardware/nano-33-ble-sense-rev2/
- https://github.com/arduino-libraries/Arduino_BMI270_BMM150/blob/master/src/BMI270.cpp
- https://github.com/arduino-libraries/Arduino_LPS22HB/blob/master/src/BARO.cpp
- https://docs.arduino.cc/resources/datasheets/REN_HS300x-Datasheet_DST.pdf
